# Programmieraufgabe - Repository Vorlage
Im Verzeichnis `src/` sind alle Quelltextdateien und Pakete abzulegen. Elemente außerhalb des `src/` Verzeichnisses werden nicht kompiliert und folglich nicht berücksichtigt.
